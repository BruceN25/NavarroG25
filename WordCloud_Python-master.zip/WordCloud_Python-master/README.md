# Nube de Palaras con Python - Proceso de Software
Proyecto del primer parcial de la materia de Procesos de Software. Realizará un web scraping de un usuario en StackOverFlow obteniendo sus etiquetas y votos de cada una.
1. Se realiza el web scraping.
2. Se genera la nube de palabras de los datos obtenidos en el web scraping.
3. Se genera la nube de palabras con las etiquetas obtenidas en el web scraping, a los que se les asigna su respectivo voto.
